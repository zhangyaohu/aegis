var express = require('express');
var router = express.Router();
const db = require('../mysql/dbConfig.js')
const {Encrypt, Decrypt} = require('../utils');

router.post('/login', async function(req, res) {
	var {name, password} = {...req.body};
	var sql = `select * from users where username='${name}' and password='${password}'`;
	let user = {};
	await db.query(sql, (err, rows) => {
		user = JSON.parse(JSON.stringify(rows));
	});
	if(name==='admin' && password==="123456") {
		req.session.sid = name;
		await db.query(`select * from users_current where user_id='${name}'`, (err, rows) => {
			if (!rows) {
				let $sql = `insert into users_current values(${user[0].id}, now())`;
				db.query(sql, () => {

				})
				$sql = `insert into users_logins(user_id, user_name) values(${user[0].id},${user[0].username})`;
				db.query(sql, () => {

				})
		 }
		});
		res.json({status:200, code: 200, data: '登录成功'});
	}else{
		res.json({status:200, code: 400, data: '用户名或密码错误'});
	}
})

module.exports = router;